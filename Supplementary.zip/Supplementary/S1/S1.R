


###########################################################################################################################################################
#                                                                                                                                                         #
#                                                                Script for "figure S 1" of paper                                                         # 
#  Microbiome changes in chronic heart failure with preserved ejection fraction patients correlate with fibrosis markers: description of Russian cohort   #
# R version 3.6.1 (2019-07-05)                                                                                                                            #
# Script for differential analysis of Picrust2 dataset                                                                                                    #
#                                                                                                                                                         #
###########################################################################################################################################################

# Instal packages
install.packages("RCurl")
install.packages("dplyr")
install.packages("data.table")
install.packages("ggrepel")
# Load librarys
library( RCurl )
library(ggplot2)
library(dplyr)
library(data.table)
library(ggrepel)


# Set working directory

setwd("C:/R project/")
getwd()



# Load data, output from Qiime-Picrust2 after biom convert
Picrust2<-as.data.frame(fread("KOfeature-table.tsv"))

dim(Picrust2)
Picrust2[1:4,1:4]

# Data format
Picrust2C <- data.frame(Picrust2[,-1], row.names=Picrust2[,1])

dim(Picrust2C)
Picrust2C[1:4,1:4]

############


Picrust2C[Picrust2C == 0] <- 1

#Data -Log10 transformation

LogPicrust2C <- log2(Picrust2C)
dim(LogPicrust2C)
LogPicrust2C[1:4,1:6]


############

# Load filtration metadata
CHFind <- read.csv("C:/path to/metaCHF_S1.csv", header=TRUE, sep=";")
dim(CHFind)

Helthind <- read.csv("C:/path to/metaHealth_S1.csv", header=TRUE, sep=";")
dim(Helthind)

CHFmetaIn <- read.csv("C:/path to/metaInd_S1.csv", header=TRUE, sep=";")# add function to subtrac Health+CHF
dim(CHFmetaIn)

# subtract Health+CHF
CHFmetaM <- as.matrix(CHFmetaIn)
str(CHFmetaM)
CHFmeta  <- LogPicrust2C[ ,CHFmetaM]
dim(CHFmeta)
CHFmeta[1:4,1:4]
# subtract CHF
CHFset <- as.matrix(CHFind)
str(CHFset)
CHFpath  <- LogPicrust2C[ ,CHFset]
dim(CHFpath)
CHFpath[1:4,1:4]
# subtract Health
Helthset <- as.matrix(Helthind)
str(Helthset)
Helthpath <- LogPicrust2C[ ,Helthset]
dim(Helthpath)
Helthpath[1:4,1:4]

# Calculate mean  for health and CHF

Helthpath.mean = apply(Helthpath, 1, mean)
CHFpath.mean = apply(CHFpath, 1, mean)

# Calculate difference 
fold = CHFpath.mean - Helthpath.mean

hist(fold, col = "gray")

# T test
pvalue = NULL 
tstat = NULL

for(i in 1 : nrow(CHFmeta)) { # For each gene : 
  x = Helthpath[i,] # WT of gene number i
  y = CHFpath[i,] # KO of gene number i
  
  # Compute t-test between the two conditions
  t = t.test(x, y)
  
  # Put the current p-value in the pvalues list
  pvalue[i] = t$p.value
  # Put the current t-statistic in the tstats list
  tstat[i] = t$statistic
}

head(pvalue)
dim(pvalue)
# Histogram of p-values (-log10)
hist(-log10(pvalue), col = "gray")

plot(fold, -log10(pvalue), main = "Volcano")

fold_cutoff = 1
pvalue_cutoff = 0.05
abline(v = fold_cutoff, col = "blue", lwd = 3)
abline(v = -fold_cutoff, col = "red", lwd = 3)
abline(h = -log10(pvalue_cutoff), col = "green", lwd = 3)

# Fold-change filter for "biological" significance
filter_by_fold = abs(fold) >= fold_cutoff
dim(CHFmeta[filter_by_fold, ])

# P-value filter for "statistical" significance
filter_by_pvalue = pvalue <= pvalue_cutoff
dim(CHFmeta[filter_by_pvalue, ])

# Combined filter (both biological and statistical)
filter_combined = filter_by_fold & filter_by_pvalue
dim(filter_combined)
filtered = CHFmeta[filter_combined,]

dim(filtered)

filtered[1:4,1:4]
#Generate output table

autput.table <- data.frame(Helthpath.mean,CHFpath.mean,fold,pvalue)
dim(autput.table)
autput.table[1:8,1:4]

#Filter Up regulated Gene

UpGeneAuT <- autput.table[(autput.table$fold > fold_cutoff) & (autput.table$pvalue < pvalue_cutoff),]
dim(UpGeneAuT)
UpGeneAuT[1:15,1:4]
#write.table(UpGeneAuT, "UpGeneAuT_7_05.txt", col.names=NA, sep="\t")

#Filter Down regulated Gene

DownGeneAuT <- autput.table[(autput.table$fold < -fold_cutoff) & (autput.table$pvalue < pvalue_cutoff),]
dim(DownGeneAuT)
DownGeneAuT[1:15,1:4]

UpAndDown <- rbind(DownGeneAuT,UpGeneAuT)

#Load assignment tables

AssigmentTable <- read.csv("C:/path to/PicrustAnnotation.csv", header=TRUE, sep=";") # Alist of caloring for vulcano plot generated from "UpAndDownAnotation"



#Make a row names as first column in Output Table

d2 <- autput.table
SamplNames2 <- rownames(d2)
rownames(d2) <- NULL
KOnumberAutputTable <- cbind(SamplNames2,d2)

#Make a row names as first column in "UpAndDown" Table

d3 <- UpAndDown
SamplNames3 <- rownames(d3)
rownames(d3) <- NULL
KOnumberUpAndDown <- cbind(SamplNames3,d3)

AutputTableCalor <- merge(KOnumberAutputTable, AssigmentTable,by.x=1,by.y=6,all = F)
write.table(AutputTableCalor, "AutputTableCalor_S1.txt", col.names=NA, sep="\t")

AutputTableUpAndDown <- merge(KOnumberUpAndDown, AssigmentTable,by.x=1,by.y=6,all = F)


# Make list for labeling in volcano plot

LableSet <- read.csv("C:/path to/LabelSet.csv", header=TRUE, sep=";")


# Highlighting up-regulated in red and down-regulated in blue with lable spesific points
plot(-log10(pvalue)~fold, xlab = 'log2(fold change)', ylab = '-log10(pvalue)', main = 'Health VS HCF Volcano #6', data = autput.table,xlim=c(-10,25))
points (fold[filter_combined & fold < 0],
        -log10(pvalue[filter_combined & fold < 0]),
        pch = 16, col = "blue")
points (fold[filter_combined & fold > 0],
        -log10(pvalue[filter_combined & fold > 0]),
        pch = 16, col = "red")
abline(v = fold_cutoff, col = "red", lwd = 3)
abline(v = -fold_cutoff, col = "red", lwd = 3)
abline(h = -log10(pvalue_cutoff), col = "green", lwd = 3)
#geom_text(data=LableSet, aes(label=Gene.name))
#with(LableSet, text(-log10(pvalue)~fold, labels = Gene.name, pos = 1))
geom_text_repel(data=LableSet, aes(label=Gene.name))

